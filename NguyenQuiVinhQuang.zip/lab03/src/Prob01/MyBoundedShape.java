package Prob01;

public abstract class MyBoundedShape extends MyShape {
    public abstract void GetArea(double x, double y);
}
