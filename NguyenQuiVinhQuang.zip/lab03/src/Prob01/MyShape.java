package Prob01;

public abstract class MyShape {
    public abstract void Draw();
}
