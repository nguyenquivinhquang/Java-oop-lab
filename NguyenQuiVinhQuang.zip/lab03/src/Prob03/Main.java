package Prob03;

public class Main {
    public static void main(String[] args) {
        Student student = new Student("Quang", "LLL", "Bachelo", 2019, 42000);
        System.out.print(student.toString());
    }
}
