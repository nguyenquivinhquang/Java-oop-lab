public class TestMyTriangle {
    public static void main(String[] args) {
        MyTriangle test = new MyTriangle(1, 3, 2, 5, 7, 9);
        System.out.println(test.toString());
        System.out.print(test.getType());
    }
}
